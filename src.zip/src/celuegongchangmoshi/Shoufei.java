package celuegongchangmoshi;

public interface Shoufei {
    public double shoufei(double money);

}
