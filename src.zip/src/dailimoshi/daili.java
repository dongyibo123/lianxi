package dailimoshi;
public class daili implements Jk {
    Zqz zz;
    public daili(Bzqz mm){
        zz = new Zqz(mm);
    }

    @Override
    public void getfellow() {
        zz.getfellow();
    }

    @Override
    public void getqiaokeli() {
        zz.getqiaokeli();
    }

    @Override
    public void getxiaodao() {
        zz.getxiaodao();
    }
}
