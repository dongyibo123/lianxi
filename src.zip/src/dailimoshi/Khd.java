package dailimoshi;
public class Khd {
    public static void main(String[] args) {
        Bzqz jiaojiao =new Bzqz();
        jiaojiao.setName("Ů��");
        daili daili1 =new daili(jiaojiao);
        daili1.getfellow();
        daili1.getqiaokeli();
        daili1.getxiaodao();
    }
}
