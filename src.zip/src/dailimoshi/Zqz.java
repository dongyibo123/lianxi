package dailimoshi;
public class Zqz implements Jk {
    Bzqz mm;
    public Zqz(Bzqz mm){
        this.mm = mm;
    }
    @Override
    public void getfellow() {
        System.out.println(mm.name+"���㻨");
    }

    @Override
    public void getqiaokeli() {
        System.out.println(mm.name+"�����ɿ���");
    }

    @Override
    public void getxiaodao() {
        System.out.println(mm.name+"����С��");
    }
}
