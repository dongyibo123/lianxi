package yuanxingmoshi;

public class ckd {
    public static void main(String[] args) {
        Resume a = new  Resume("С��");
        a.setPersonalInfo("18","��");
        a.setWorkExperience("3��","��Ѷ");
        Resume b = a.clone("С��");
        b.setWorkExperience("2���","����");
        Resume c = a.clone("С��");
        c.setPersonalInfo("25","Ů");
        a.display();
        b.display();
        c.display();
    }
}
