package waiguanmoshi;

public class SubSystemFour {
    public void methodFour()
    {
        System.out.println("����500B��");
    }
}
