package waiguanmoshi;

public class SubSystemThree {
    public void methodThree()
    {
        System.out.println("����200A��");
    }
}
