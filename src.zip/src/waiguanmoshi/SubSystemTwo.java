package waiguanmoshi;

public class SubSystemTwo {
    public void methodTwo()
    {
        System.out.println("����1000B��");
    }
}
