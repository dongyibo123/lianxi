package waiguanmoshi;

public class SubSystemOne {
    public void methodOne()
    {
        System.out.println("����500A��");
    }
}
