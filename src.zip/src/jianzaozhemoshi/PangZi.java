package jianzaozhemoshi;

import java.awt.*;

public class PangZi extends PersonBuilder{

    public PangZi(Graphics g) {
        super(g);
    }
    public void buildArmLeft()
    {
        g.drawLine(180, 240, 120, 390);// ����
    }

    public void buildArmRight()
    {
        g.drawLine(390, 360, 280, 240);// ����
    }

    public void buildBody()
    {
        g.fillRect(180, 240, 100, 150);// ����
    }

    public void buildHead()
    {
        g.fillOval(180, 150, 90, 90);// ͷ
    }

    public void buildLegLeft()
    {
        g.drawLine(220, 390, 135, 540);// ����
    }

    public void buildLegRight()
    {
        g.drawLine(250, 390, 275, 540);// ����
    }
}
