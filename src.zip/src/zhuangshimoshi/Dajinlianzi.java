package zhuangshimoshi;

public class Dajinlianzi extends Chuanda{
    public void show() {
        super.show();
        System.out.println("�������");
    }
}
