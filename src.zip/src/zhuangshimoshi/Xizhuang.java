package zhuangshimoshi;

public class Xizhuang extends Chuanda {
    public void show() {
        super.show();
        System.out.println("��װ");
    }
}
