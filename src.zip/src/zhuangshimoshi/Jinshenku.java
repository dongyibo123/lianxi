package zhuangshimoshi;

public class Jinshenku extends Chuanda{
    public void show() {
        super.show();
        System.out.println("������");
    }
}
