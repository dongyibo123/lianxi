package zhuangshimoshi;

public class Laolishi extends Chuanda{
    public void show() {
        super.show();
        System.out.println("������ʿ");
    }
}
