package zhuangshimoshi;

public class Person {
    private String Name;
    public Person(){

    }
    public Person(String Name){
        this.Name=Name;
    }
    public void show(){
        System.out.println(Name+"�Ĵ���");
    }
}
