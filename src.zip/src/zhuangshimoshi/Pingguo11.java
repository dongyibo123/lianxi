package zhuangshimoshi;

public class Pingguo11 extends Chuanda {
    public void show() {
        super.show();
        System.out.println("ƻ��11");
    }
}
