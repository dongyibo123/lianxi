package zhuangshimoshi;

public class khd {
    public static void main(String[] args) {
        Person person1 = new Person("�ɹ���ʿ");
        Xizhuang xizhuang =new Xizhuang();
        Lingdai lingdai = new Lingdai();
        Laolishi laolishi = new Laolishi();
        Pixie pixie =new Pixie();
        xizhuang.decorate(person1);
        lingdai.decorate(xizhuang);
        laolishi.decorate(lingdai);
        pixie.decorate(laolishi);
        pixie.show();
        Person person2 =new Person("����");
        Dajinlianzi dajinlianzi =new Dajinlianzi();
        Pingguo11 pingguo11 =new Pingguo11();
        dajinlianzi.decorate(person2);
        pingguo11.decorate(dajinlianzi);
        pingguo11.show();
        Person person3= new Person("����С��");
        Jinshenyi jinshenyi =new Jinshenyi();
        Jinshenku jinshenku =new Jinshenku();
        Doudouxie doudouxie =new Doudouxie();
        jinshenyi.decorate(person3);
        jinshenku.decorate(jinshenyi);
        doudouxie.decorate(jinshenku);
        doudouxie.show();
    }
}
