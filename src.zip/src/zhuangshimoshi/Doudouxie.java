package zhuangshimoshi;

public class Doudouxie extends Chuanda{
    public void show() {
        super.show();
        System.out.println("����Ь");
    }
}
