package zhuangshimoshi;

public class Pixie extends Chuanda {
    public void show() {
        super.show();
        System.out.println("�����ƤЬ");
    }
}
