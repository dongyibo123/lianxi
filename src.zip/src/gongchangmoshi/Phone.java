package gongchangmoshi;
public interface Phone {
    void make();
}